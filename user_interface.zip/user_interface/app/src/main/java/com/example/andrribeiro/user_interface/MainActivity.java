package com.example.andrribeiro.user_interface;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = (Button) findViewById(R.id.button);
        Button btn1 = (Button) findViewById(R.id.button2);
        Button btn2 = (Button) findViewById(R.id.button3);
        ImageView img = (ImageButton) findViewById(R.id.img);

    }

    public void btnClick(View v) {
        Toast.makeText(this, "Histórico", Toast.LENGTH_SHORT).show();
    }

    public void btn1Click(View v) {
        Toast.makeText(this, "Casa", Toast.LENGTH_SHORT).show();
    }

    public void btn2Click(View v) {
        Toast.makeText(this, "Favoritos", Toast.LENGTH_SHORT).show();
    }


    public void imgonClick(View v) {
        {
            Toast.makeText(this, "GPS", Toast.LENGTH_SHORT).show();


        }
    }
}

