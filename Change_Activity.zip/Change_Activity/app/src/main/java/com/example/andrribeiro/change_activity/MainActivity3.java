package com.example.andrribeiro.change_activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity3 extends AppCompatActivity {
    ListView lv;
    String[] characters = {"Percurso 1", "Percurso 2", "Percurso 3", "Percurso 4", "Percurso 5","Percurso 6", "Percurso 7", "Percurso 8", "Percurso 9", "Percurso 10", "Percurso 11"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        lv = (ListView) findViewById(R.id.idListView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, characters);
        lv.setAdapter(adapter);
    }
}
